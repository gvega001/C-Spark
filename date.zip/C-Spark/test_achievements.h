#ifndef TEST_ACHIEVEMENTS_H
#define TEST_ACHIEVEMENTS_H

void test_unlock_achievement();
void test_save_and_load_achievements();

#endif // TEST_ACHIEVEMENTS_H
