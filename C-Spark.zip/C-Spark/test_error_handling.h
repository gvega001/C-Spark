#ifndef TEST_ERROR_HANDLING_H
#define TEST_ERROR_HANDLING_H

void test_report_error();
void test_log_error();

#endif // TEST_ERROR_HANDLING_H

