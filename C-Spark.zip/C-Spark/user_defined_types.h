// include/user_defined_types.h
#ifndef USER_DEFINED_TYPES_H
#define USER_DEFINED_TYPES_H

void parse_struct_union_declaration(const char* declaration);

#endif // USER_DEFINED_TYPES_H

